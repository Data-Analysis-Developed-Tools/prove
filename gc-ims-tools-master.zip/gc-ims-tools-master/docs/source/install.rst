Install
=======
*gc-ims-tools* requires Python 3.8+ and can be installed with pip:

:: 
    
    pip install gc-ims-tools


It depends on:

    * numpy
    * pandas
    * scipy
    * matplotlib
    * seaborn
    * h5py
    * scikit-learn
    * scikit-image
    * findpeaks
