

Getting started
===============

.. toctree::
   :maxdepth: 2

   install

API-Reference
=============

.. toctree::
   :maxdepth: 2

   ims.gcims
   ims.dataset
   ims.pca
   ims.plsr
   ims.plsda
   ims.hca


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
