PLSR
====

.. automodule:: ims.plsr
   :members:
   :undoc-members:
   :show-inheritance:
