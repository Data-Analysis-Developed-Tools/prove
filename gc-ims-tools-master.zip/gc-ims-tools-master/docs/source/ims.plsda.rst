PLS_DA
======

.. automodule:: ims.plsda
   :members:
   :undoc-members:
   :show-inheritance:
